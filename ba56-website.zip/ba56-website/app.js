/* BA56 — Interactions, Cart, Filtering, Modals */

(function () {
  'use strict';

  // ---------- STATE ----------
  let cart = JSON.parse(localStorage.getItem('ba56_cart') || '[]');
  let currentProduct = null;
  let selectedSize = null;
  let qty = 1;

  // ---------- HELPERS ----------
  const formatPKR = (n) => 'PKR ' + n.toLocaleString('en-PK');

  const $ = (sel, ctx = document) => ctx.querySelector(sel);
  const $$ = (sel, ctx = document) => [...ctx.querySelectorAll(sel)];

  function saveCart() {
    localStorage.setItem('ba56_cart', JSON.stringify(cart));
    updateBagUI();
  }

  function showToast(msg) {
    const t = $('#toast');
    t.textContent = msg;
    t.classList.add('show');
    setTimeout(() => t.classList.remove('show'), 2600);
  }

  // ---------- RENDER PRODUCTS ----------
  function productCardHTML(p) {
    return `
      <article class="product-card" data-id="${p.id}" data-cat="${p.category}">
        <div class="product-image-wrap">
          ${p.badge ? `<span class="product-badge">${p.badge}</span>` : ''}
          <img src="${p.image}" alt="${p.name}" loading="lazy" />
          <div class="product-actions">
            <button type="button" class="qv-btn" data-id="${p.id}">Quick View</button>
            <button type="button" class="add-btn" data-id="${p.id}">Add to Bag</button>
          </div>
        </div>
        <div class="product-body">
          <div class="product-cat">${p.catLabel}</div>
          <h3 class="product-name">${p.name}</h3>
          <p class="product-desc">${p.desc}</p>
          <div class="product-meta">
            <span class="product-price">${formatPKR(p.price)}</span>
            <span class="product-rating">★ ${p.rating}</span>
          </div>
        </div>
      </article>
    `;
  }

  function renderProducts(list, containerId) {
    const el = $(containerId);
    if (!el) return;
    el.innerHTML = list.map(productCardHTML).join('');
  }

  function renderFeatured() {
    renderProducts(PRODUCTS.filter(p => p.featured), '#featuredGrid');
  }

  function renderCricket(filter = 'all') {
    const list = filter === 'all' ? PRODUCTS : PRODUCTS.filter(p => p.category === filter);
    renderProducts(list, '#cricketGrid');
  }

  function renderBestsellers() {
    renderProducts(PRODUCTS.filter(p => p.bestseller), '#bestsellerGrid');
  }

  function renderHeritage() {
    const grid = $('#heritageGrid');
    if (!grid) return;
    grid.innerHTML = HERITAGE_IMAGES.map(h => `
      <div class="heritage-item">
        <img src="${h.img}" alt="${h.title}" loading="lazy" />
        <div class="heritage-caption">
          <h4>${h.title}</h4>
          <span>${h.sub}</span>
        </div>
      </div>
    `).join('');
  }

  function renderPlayers() {
    const grid = $('#playerGrid');
    if (!grid) return;
    grid.innerHTML = PLAYERS.map(p => `
      <article class="player-card">
        <div class="player-era">${p.era}</div>
        <h3 class="player-name">${p.name}</h3>
        <div class="player-country">${p.country}</div>
        <p class="player-trait">${p.trait}</p>
        <p class="player-quote">${p.quote}</p>
        <a href="#heritage" class="player-link">Explore Era →</a>
      </article>
    `).join('');
  }

  function renderScorecard() {
    const rows = $('#scoreRows');
    if (!rows) return;
    rows.innerHTML = SCORECARD.map(s => `
      <div class="score-row">
        <span class="player-name-sc">${s.player}</span>
        <span>${s.runs}</span>
        <span>${s.balls}</span>
        <span>${s.sr}</span>
        <span class="detail">${s.era} · ${s.boundaries}</span>
      </div>
    `).join('');
  }

  // ---------- CART ----------
  function updateBagUI() {
    const count = cart.reduce((sum, i) => sum + i.qty, 0);
    const badge = $('#bagCount');
    badge.textContent = count;
    badge.classList.toggle('visible', count > 0);

    const itemsEl = $('#cartItems');
    if (!cart.length) {
      itemsEl.innerHTML = '<p class="cart-empty">Your bag is empty.<br>Add something that feels like home.</p>';
    } else {
      itemsEl.innerHTML = cart.map(item => {
        const p = PRODUCTS.find(x => x.id === item.id);
        if (!p) return '';
        return `
          <div class="cart-item" data-id="${item.id}">
            <img src="${p.image}" alt="${p.name}" />
            <div>
              <div class="cart-item-name">${p.name}</div>
              <div class="cart-item-price">${formatPKR(p.price)}</div>
              <div class="cart-item-qty">Qty: ${item.qty}${item.size ? ' · ' + item.size : ''}</div>
            </div>
            <button type="button" class="cart-remove" data-id="${item.id}">Remove</button>
          </div>
        `;
      }).join('');
    }

    const subtotal = cart.reduce((sum, i) => {
      const p = PRODUCTS.find(x => x.id === i.id);
      return sum + (p ? p.price * i.qty : 0);
    }, 0);

    $('#cartSubtotal').textContent = formatPKR(subtotal);
    $('#cartTotal').textContent = formatPKR(subtotal);
    const delivery = $('#cartDelivery');
    if (subtotal >= 10000) {
      delivery.textContent = 'FREE';
    } else if (subtotal > 0) {
      delivery.textContent = 'PKR 350 (est.)';
    } else {
      delivery.textContent = 'Calculated at checkout';
    }
  }

  function addToCart(id, size = null, quantity = 1) {
    const existing = cart.find(i => i.id === id && i.size === size);
    if (existing) {
      existing.qty += quantity;
    } else {
      cart.push({ id, size, qty: quantity });
    }
    saveCart();
    showToast('Added to bag');
  }

  function removeFromCart(id) {
    cart = cart.filter(i => i.id !== id);
    saveCart();
    showToast('Removed from bag');
  }

  // ---------- QUICK VIEW ----------
  function openQuickView(id) {
    const p = PRODUCTS.find(x => x.id === id);
    if (!p) return;
    currentProduct = p;
    selectedSize = p.sizes[0] || null;
    qty = 1;

    $('#qvImg').src = p.image;
    $('#qvImg').alt = p.name;
    $('#qvCat').textContent = p.catLabel;
    $('#qvTitle').textContent = p.name;
    $('#qvRating').textContent = '★ ' + p.rating;
    $('#qvPrice').textContent = formatPKR(p.price);
    $('#qvDesc').textContent = p.desc;
    $('#qvQty').value = 1;

    const sizesEl = $('#qvSizes');
    sizesEl.innerHTML = p.sizes.map((s, i) =>
      `<button type="button" class="${i === 0 ? 'active' : ''}" data-size="${s}">${s}</button>`
    ).join('');

    $('#quickViewModal').classList.add('open');
    $('#quickViewModal').setAttribute('aria-hidden', 'false');
    document.body.style.overflow = 'hidden';
  }

  function closeQuickView() {
    $('#quickViewModal').classList.remove('open');
    $('#quickViewModal').setAttribute('aria-hidden', 'true');
    document.body.style.overflow = '';
  }

  // ---------- CART DRAWER ----------
  function openCart() {
    $('#cartDrawer').classList.add('open');
    $('#cartDrawer').setAttribute('aria-hidden', 'false');
    document.body.style.overflow = 'hidden';
  }

  function closeCart() {
    $('#cartDrawer').classList.remove('open');
    $('#cartDrawer').setAttribute('aria-hidden', 'true');
    document.body.style.overflow = '';
  }

  // ---------- SEARCH ----------
  function openSearch() {
    $('#searchOverlay').classList.add('open');
    $('#searchOverlay').setAttribute('aria-hidden', 'false');
    setTimeout(() => $('#searchInput').focus(), 100);
  }

  function closeSearch() {
    $('#searchOverlay').classList.remove('open');
    $('#searchOverlay').setAttribute('aria-hidden', 'true');
    $('#searchInput').value = '';
    $('#searchResults').innerHTML = '';
  }

  function runSearch(q) {
    q = q.trim().toLowerCase();
    const results = $('#searchResults');
    if (!q) {
      results.innerHTML = '';
      return;
    }
    const matches = PRODUCTS.filter(p =>
      p.name.toLowerCase().includes(q) ||
      p.category.toLowerCase().includes(q) ||
      p.desc.toLowerCase().includes(q) ||
      (p.badge && p.badge.toLowerCase().includes(q))
    );
    if (!matches.length) {
      results.innerHTML = '<p style="color:rgba(232,224,213,0.5);font-size:0.9rem;">No products found.</p>';
      return;
    }
    results.innerHTML = matches.map(p => `
      <div class="search-result-item" data-id="${p.id}">
        <img src="${p.image}" alt="" />
        <div>
          <div style="font-weight:500;">${p.name}</div>
          <div style="font-size:0.8rem;opacity:0.7;">${formatPKR(p.price)}</div>
        </div>
      </div>
    `).join('');
  }

  // ---------- CHECKOUT ----------
  function openCheckout() {
    if (!cart.length) {
      showToast('Your bag is empty');
      return;
    }
    closeCart();
    $('#checkoutFormView').hidden = false;
    $('#orderConfirmView').hidden = true;
    $('#checkoutModal').classList.add('open');
    $('#checkoutModal').setAttribute('aria-hidden', 'false');
    document.body.style.overflow = 'hidden';
  }

  function closeCheckout() {
    $('#checkoutModal').classList.remove('open');
    $('#checkoutModal').setAttribute('aria-hidden', 'true');
    document.body.style.overflow = '';
  }

  // ---------- EVENT BINDING ----------
  function bindEvents() {
    // Sticky header
    const header = $('#siteHeader');
    window.addEventListener('scroll', () => {
      header.classList.toggle('scrolled', window.scrollY > 40);
    }, { passive: true });

    // Mobile menu
    const menuToggle = $('#menuToggle');
    const mobileMenu = $('#mobileMenu');
    menuToggle.addEventListener('click', () => {
      const open = mobileMenu.classList.toggle('open');
      menuToggle.setAttribute('aria-expanded', open);
      mobileMenu.setAttribute('aria-hidden', !open);
      document.body.style.overflow = open ? 'hidden' : '';
    });
    mobileMenu.querySelectorAll('a').forEach(a => {
      a.addEventListener('click', () => {
        mobileMenu.classList.remove('open');
        menuToggle.setAttribute('aria-expanded', 'false');
        document.body.style.overflow = '';
      });
    });

    // Search
    $('#searchBtn').addEventListener('click', openSearch);
    $('#closeSearch').addEventListener('click', closeSearch);
    $('#searchOverlay').addEventListener('click', (e) => {
      if (e.target === $('#searchOverlay')) closeSearch();
    });
    $('#searchInput').addEventListener('input', (e) => runSearch(e.target.value));
    $$('.search-suggestions button').forEach(btn => {
      btn.addEventListener('click', () => {
        $('#searchInput').value = btn.dataset.query;
        runSearch(btn.dataset.query);
      });
    });
    $('#searchResults').addEventListener('click', (e) => {
      const item = e.target.closest('.search-result-item');
      if (item) {
        closeSearch();
        openQuickView(item.dataset.id);
      }
    });

    // Bag
    $('#bagBtn').addEventListener('click', openCart);
    $$('[data-close-cart]').forEach(el => el.addEventListener('click', closeCart));

    // Product grid clicks (delegation)
    document.addEventListener('click', (e) => {
      const qv = e.target.closest('.qv-btn');
      if (qv) {
        openQuickView(qv.dataset.id);
        return;
      }
      const add = e.target.closest('.add-btn');
      if (add) {
        addToCart(add.dataset.id);
        return;
      }
      const remove = e.target.closest('.cart-remove');
      if (remove) {
        removeFromCart(remove.dataset.id);
        return;
      }
    });

    // Quick view
    $$('[data-close]').forEach(el => el.addEventListener('click', closeQuickView));
    $('#qvSizes').addEventListener('click', (e) => {
      if (e.target.tagName === 'BUTTON') {
        $$('#qvSizes button').forEach(b => b.classList.remove('active'));
        e.target.classList.add('active');
        selectedSize = e.target.dataset.size;
      }
    });
    $('#qvMinus').addEventListener('click', () => {
      qty = Math.max(1, qty - 1);
      $('#qvQty').value = qty;
    });
    $('#qvPlus').addEventListener('click', () => {
      qty = Math.min(10, qty + 1);
      $('#qvQty').value = qty;
    });
    $('#qvQty').addEventListener('change', (e) => {
      qty = Math.max(1, Math.min(10, parseInt(e.target.value) || 1));
      e.target.value = qty;
    });
    $('#qvAdd').addEventListener('click', () => {
      if (currentProduct) {
        addToCart(currentProduct.id, selectedSize, qty);
        closeQuickView();
      }
    });
    $('#qvBuy').addEventListener('click', () => {
      if (currentProduct) {
        addToCart(currentProduct.id, selectedSize, qty);
        closeQuickView();
        openCheckout();
      }
    });

    // Category filter
    $$('.cat-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        $$('.cat-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        renderCricket(btn.dataset.cat);
      });
    });

    // Checkout
    $('#checkoutBtn').addEventListener('click', openCheckout);
    $$('[data-close-checkout]').forEach(el => el.addEventListener('click', closeCheckout));
    $('#checkoutForm').addEventListener('submit', (e) => {
      e.preventDefault();
      const id = Date.now().toString().slice(-6);
      $('#orderId').textContent = id;
      $('#checkoutFormView').hidden = true;
      $('#orderConfirmView').hidden = false;
      cart = [];
      saveCart();
    });

    // Newsletter
    $('#newsletterForm').addEventListener('submit', (e) => {
      e.preventDefault();
      showToast('Welcome to the BA56 Club');
      e.target.reset();
    });

    // Account
    $('#accountBtn').addEventListener('click', () => {
      showToast('Sign in coming soon — shop as guest for now');
    });

    // Escape key
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') {
        closeSearch();
        closeQuickView();
        closeCart();
        closeCheckout();
        if ($('#mobileMenu').classList.contains('open')) {
          $('#mobileMenu').classList.remove('open');
          $('#menuToggle').setAttribute('aria-expanded', 'false');
          document.body.style.overflow = '';
        }
      }
    });
  }

  // ---------- INIT ----------
  function init() {
    renderFeatured();
    renderPlayers();
    renderHeritage();
    renderCricket('all');
    renderBestsellers();
    renderScorecard();
    updateBagUI();
    bindEvents();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
