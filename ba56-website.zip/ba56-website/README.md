# BA56 — Premium Cricket & Multi-Sports Store

A cinematic, nostalgia-driven e-commerce website for passionate cricket fans in Pakistan.

## Brand

**BA56** — Equipment rooted in cricket culture, legendary moments, iconic players, and the love of the game.

## How to view

Open `index.html` in a modern browser (Chrome, Firefox, Safari, Edge).

No build step required. Product imagery loads from Unsplash.

## Features

- Sticky editorial navigation
- Cinematic hero with analog details
- Player archive (“The Game Has a Memory”)
- Heritage Collection
- Pakistan cricket culture section
- Full cricket product catalogue with category filtering
- Multi-sport category cards
- Interactive analog scorecard
- Product Quick View modal
- Shopping bag with free-delivery threshold (PKR 10,000)
- Checkout with Cash on Delivery / Card options
- Order confirmation
- Search overlay with live filtering
- Newsletter / BA56 Club signup
- Fully responsive (desktop / tablet / mobile)
- Keyboard accessible (Escape closes overlays, focus states)

## Design system

- Deep forest green · Warm ivory · Charcoal · Muted cream · Dark brown · Cricket-ball red · Gold accents
- Typography: Playfair Display (serif headlines) · Inter (UI) · Courier Prime (scorebook)
- Film grain, editorial captions, handwritten-style scorecard aesthetic

## Stack

Pure HTML, CSS and vanilla JavaScript. Cart state persists in localStorage.
