/* BA56 Demo Data — Fictional products & content */

const PRODUCTS = [
  {
    id: 'bat-heritage',
    name: 'BA56 Heritage English Willow Bat',
    category: 'bats',
    catLabel: 'Bats',
    price: 18500,
    rating: 4.9,
    desc: 'Hand-selected Grade 1+ English willow. Classic profile with a generous sweet spot. Built for the player who values feel over flash.',
    image: 'https://images.unsplash.com/photo-1531415073913-493a5a4b1bb4?auto=format&fit=crop&w=600&q=80',
    badge: 'Heritage',
    sizes: ['SH', 'Harrow', 'Short Handle'],
    featured: true,
    bestseller: true,
    heritage: true
  },
  {
    id: 'ball-karachi',
    name: 'BA56 Karachi Pro Match Ball',
    category: 'balls',
    catLabel: 'Balls',
    price: 4200,
    rating: 4.7,
    desc: 'Premium four-piece leather ball. Hand-stitched, water-resistant finish. Designed for consistent bounce and shine retention.',
    image: 'https://images.unsplash.com/photo-1540747913346-19e32dc3e97e?auto=format&fit=crop&w=600&q=80',
    badge: null,
    sizes: ['Standard'],
    featured: true,
    bestseller: true
  },
  {
    id: 'gloves-test',
    name: 'BA56 Test Series Batting Gloves',
    category: 'gloves',
    catLabel: 'Gloves',
    price: 7800,
    rating: 4.8,
    desc: 'Multi-section protection with premium sheepskin palm. Lightweight yet robust — the gloves you forget you are wearing.',
    image: 'https://images.unsplash.com/photo-1595435934249-5df7ca71d62b?auto=format&fit=crop&w=600&q=80',
    badge: null,
    sizes: ['S', 'M', 'L', 'XL'],
    featured: true,
    bestseller: false
  },
  {
    id: 'helmet-classic',
    name: 'BA56 Classic Green Cricket Helmet',
    category: 'helmets',
    catLabel: 'Helmets',
    price: 12500,
    rating: 4.6,
    desc: 'Lightweight titanium grille. Ventilated shell in deep forest green. Inspired by the colours of classic Test cricket.',
    image: 'https://images.unsplash.com/photo-1624526267942-ab0ff8a3e972?auto=format&fit=crop&w=600&q=80',
    badge: 'New',
    sizes: ['S', 'M', 'L'],
    featured: true,
    bestseller: true
  },
  {
    id: 'bag-duffle',
    name: 'BA56 Heritage Duffle Bag',
    category: 'bags',
    catLabel: 'Bags',
    price: 9900,
    rating: 4.8,
    desc: 'Waxed canvas and leather. Room for a full kit, a scorebook and the stories that come with them.',
    image: 'https://images.unsplash.com/photo-1553062407-98eeb64c6a62?auto=format&fit=crop&w=600&q=80',
    badge: 'Heritage',
    sizes: ['One Size'],
    featured: false,
    bestseller: true,
    heritage: true
  },
  {
    id: 'jersey-90s',
    name: 'BA56 90s Cricket Jersey',
    category: 'jerseys',
    catLabel: 'Jerseys',
    price: 6500,
    rating: 4.9,
    desc: 'Retro cut, breathable fabric. Subtle archive numbering. For those who still remember the green of ’92.',
    image: 'https://images.unsplash.com/photo-1574629810360-7efbbe195018?auto=format&fit=crop&w=600&q=80',
    badge: 'Archive',
    sizes: ['S', 'M', 'L', 'XL', 'XXL'],
    featured: true,
    bestseller: true,
    heritage: true
  },
  {
    id: 'stumps-pro',
    name: 'BA56 Pro Training Stumps',
    category: 'training',
    catLabel: 'Training',
    price: 5600,
    rating: 4.5,
    desc: 'Ash wood stumps with brass ferrules. Weighted base for net sessions and backyard battles alike.',
    image: 'https://images.unsplash.com/photo-1531415073913-493a5a4b1bb4?auto=format&fit=crop&w=600&q=80',
    badge: null,
    sizes: ['Full Set'],
    featured: false,
    bestseller: false
  },
  {
    id: 'pads-test',
    name: 'BA56 Test Match Batting Pads',
    category: 'pads',
    catLabel: 'Pads',
    price: 11200,
    rating: 4.7,
    desc: 'Traditional cane construction with modern foam. Lightweight protection that moves with you.',
    image: 'https://images.unsplash.com/photo-1595435934249-5df7ca71d62b?auto=format&fit=crop&w=600&q=80',
    badge: null,
    sizes: ['S', 'M', 'L'],
    featured: false,
    bestseller: false
  },
  {
    id: 'shoes-spike',
    name: 'BA56 Ground Spike Shoes',
    category: 'shoes',
    catLabel: 'Shoes',
    price: 14500,
    rating: 4.6,
    desc: 'Full-grain leather upper. Replaceable metal spikes. Built for the long hours between overs.',
    image: 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&w=600&q=80',
    badge: null,
    sizes: ['7', '8', '9', '10', '11', '12'],
    featured: false,
    bestseller: true
  },
  {
    id: 'sweater-cream',
    name: 'BA56 Cream Cricket Sweater',
    category: 'jerseys',
    catLabel: 'Jerseys',
    price: 8900,
    rating: 4.9,
    desc: 'Cable-knit merino blend. The classic cream sweater of county and Test cricket, reimagined.',
    image: 'https://images.unsplash.com/photo-1576566588028-4147f3842fbf?auto=format&fit=crop&w=600&q=80',
    badge: 'Heritage',
    sizes: ['S', 'M', 'L', 'XL'],
    featured: false,
    bestseller: false,
    heritage: true
  },
  {
    id: 'ball-leather',
    name: 'BA56 Vintage Leather Practice Ball',
    category: 'balls',
    catLabel: 'Balls',
    price: 2800,
    rating: 4.4,
    desc: 'Two-piece leather for nets and tape-ball nostalgia. Softens beautifully with use.',
    image: 'https://images.unsplash.com/photo-1540747913346-19e32dc3e97e?auto=format&fit=crop&w=600&q=80',
    badge: null,
    sizes: ['Standard'],
    featured: false,
    bestseller: false,
    heritage: true
  },
  {
    id: 'bag-kit',
    name: 'BA56 Classic Kit Bag',
    category: 'bags',
    catLabel: 'Bags',
    price: 7500,
    rating: 4.5,
    desc: 'Heavy-duty canvas with leather straps. Enough space for pads, gloves, bat and a change of whites.',
    image: 'https://images.unsplash.com/photo-1553062407-98eeb64c6a62?auto=format&fit=crop&w=600&q=80',
    badge: null,
    sizes: ['One Size'],
    featured: false,
    bestseller: false,
    heritage: true
  }
];

const PLAYERS = [
  {
    name: 'Babar Azam',
    country: 'Pakistan',
    era: '2015 — Present',
    trait: 'Silky timing, calm under pressure, the modern face of Pakistani batting.',
    quote: '“Technique that looks like poetry.”'
  },
  {
    name: 'Wasim Akram',
    country: 'Pakistan',
    era: '1984 — 2003',
    trait: 'The sultan of swing. Left-arm magic that rewrote the art of reverse.',
    quote: '“Two sides of the same ball.”'
  },
  {
    name: 'Sachin Tendulkar',
    country: 'India',
    era: '1989 — 2013',
    trait: 'The little master. A generation’s heartbeat at the crease.',
    quote: '“Every innings a masterclass.”'
  },
  {
    name: 'Brian Lara',
    country: 'West Indies',
    era: '1990 — 2007',
    trait: 'Elegant aggression. 400 not out still echoes.',
    quote: '“The bat as an extension of will.”'
  },
  {
    name: 'Ricky Ponting',
    country: 'Australia',
    era: '1995 — 2012',
    trait: 'Fierce competitor. The pull shot that defined an era.',
    quote: '“Leadership in every stride.”'
  },
  {
    name: 'AB de Villiers',
    country: 'South Africa',
    era: '2004 — 2018',
    trait: '360-degree genius. The most complete modern batsman.',
    quote: '“Impossible made ordinary.”'
  },
  {
    name: 'Kane Williamson',
    country: 'New Zealand',
    era: '2010 — Present',
    trait: 'Quiet excellence. Timing and temperament in perfect balance.',
    quote: '“Grace under the heaviest load.”'
  },
  {
    name: 'Virat Kohli',
    country: 'India',
    era: '2008 — Present',
    trait: 'Intensity personified. Chase-master and fitness pioneer.',
    quote: '“Hunger that never sleeps.”'
  },
  {
    name: 'Jacques Kallis',
    country: 'South Africa',
    era: '1995 — 2014',
    trait: 'The ultimate all-rounder. Bat, ball and presence.',
    quote: '“Reliability as art form.”'
  },
  {
    name: 'Muttiah Muralitharan',
    country: 'Sri Lanka',
    era: '1992 — 2010',
    trait: 'The wizard of spin. Record-breaker with a smile.',
    quote: '“Wrist and will, inseparable.”'
  }
];

const SCORECARD = [
  { player: 'Babar Azam', runs: 158, balls: 142, sr: '111.3', era: '2021 Test', boundaries: '18×4, 2×6' },
  { player: 'Wasim Akram', runs: '7/37', balls: '—', sr: '—', era: '1992 WC Final', boundaries: 'Match figures' },
  { player: 'Sachin Tendulkar', runs: 143, balls: 131, sr: '109.2', era: '1998 Sharjah', boundaries: '9×4, 5×6' },
  { player: 'Brian Lara', runs: 400, balls: 582, sr: '68.7', era: '2004 Antigua', boundaries: '43×4, 4×6' },
  { player: 'AB de Villiers', runs: 149, balls: 44, sr: '338.6', era: '2015 ODI', boundaries: '9×4, 16×6' },
  { player: 'Virat Kohli', runs: 183, balls: 148, sr: '123.6', era: '2012 Hobart', boundaries: '22×4, 1×6' },
  { player: 'Kane Williamson', runs: 148, balls: 154, sr: '96.1', era: '2019 WC SF', boundaries: '14×4, 1×6' },
  { player: 'Ricky Ponting', runs: 140, balls: 121, sr: '115.7', era: '2003 WC Final', boundaries: '4×4, 8×6' }
];

const HERITAGE_IMAGES = [
  { title: 'Cream Sweater', sub: 'The classic white', img: 'https://images.unsplash.com/photo-1576566588028-4147f3842fbf?auto=format&fit=crop&w=600&q=80' },
  { title: 'English Willow', sub: 'Hand-selected grain', img: 'https://images.unsplash.com/photo-1531415073913-493a5a4b1bb4?auto=format&fit=crop&w=600&q=80' },
  { title: 'Leather & Red', sub: 'The match ball', img: 'https://images.unsplash.com/photo-1540747913346-19e32dc3e97e?auto=format&fit=crop&w=600&q=80' }
];
